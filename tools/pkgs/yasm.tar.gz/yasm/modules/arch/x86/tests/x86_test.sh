#! /bin/sh
${srcdir}/out_test.sh x86_test modules/arch/x86/tests "x86 arch" "-f bin" ""
exit $?
